package com.example.taxast_taxi.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.taxast_taxi.R

class ChooseCar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_car)
    }
}